<?php
/**
 * Plugin Name: Tiwtter Widget
 * Description: A widget that displays Latest Tweets status via user API.
 * Version: 0.1
 * Author: Quannt
 * Author URI: http://shinetheme.com
 */

require_once(dirname(__FILE__) . '/twitteroauth.php');
if(!function_exists('tweets_widget')){
    add_action( 'widgets_init', 'tweets_widget' );
    function tweets_widget() {
        register_widget( 'Tweets_Widget' );
    }
}

class Tweets_Widget extends WP_Widget {

    function Tweets_Widget() {
        $widget_ops = array( 'classname' => 'latest-tweets', 'description' => __('Latest tweets widget ', 'mint') );
        
        $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'tweets-widget' );
        
        $this->WP_Widget( 'tweets-widget', __('Tiwtter Widget', 'mint'), $widget_ops, $control_ops );
    }
    
    function getAgo($timestamp) {
        $difference = time() - $timestamp;

        if ($difference < 60) {
            return $difference." seconds ago";
        } else {
            $difference = round($difference / 60);
        }

        if ($difference < 60) {
            return $difference." minutes ago";
        } else {
            $difference = round($difference / 60);
        }

        if ($difference < 24) {
            return $difference." hours ago";
        }
        else {
            $difference = round($difference / 24);
        }

        if ($difference < 7) {
            return $difference." days ago";
        } else {
            $difference = round($difference / 7);
            return $difference." weeks ago";
        }
    }
    function getConnectionWithAccessToken($cons_key, $cons_secret, $oauth_token, $oauth_token_secret) {
      $connection = new TwitterOAuth($cons_key, $cons_secret, $oauth_token, $oauth_token_secret);
      return $connection;
    }
    function widget( $args, $instance ) {
        extract( $args );

        //Our variables from the widget settings.
        $title = apply_filters('widget_title', $instance['title'] );
        $twitteruser = $instance['name'];
        $notweets = $instance['num'];
        $consumerkey = $instance['custommerkey'];
        $consumersecret = $instance['custommersecret'];
        $accesstoken = $instance['accesstoken'];
        $accesstokensecret = $instance['accesstokensecret'];
        $show_info = isset( $instance['show_info'] ) ? $instance['show_info'] : false;
        //Test
        //$twitteruser = "quanntvn";
//        $notweets = 3;
//        $consumerkey = "Sv4hY9ewxyyt6ffBfMiMTg";
//        $consumersecret = "w2AULbFWTu2kG3DnHRszG7HO4adpGCicE022MhuLYU";
//        $accesstoken = "1361529829-lItJW8tBYhuy1zRRYpco97TdcChNcAh6wRTZxf4";
//        $accesstokensecret = "2MRkUJLBAAp3g3PYRTcjDB4N4QaGCVf5aEuSyFaO9I";
        
        echo $before_widget;

        // Display the widget title 
      if ( $title ) {
            echo $before_title . $title . $after_title;
      }
        //Display the name 
       
            //printf( '<p>' . __('Hey their Sailor! My name is %1$s.', 'example') . '</p>', $name );
          
           $connection = $this->getConnectionWithAccessToken($consumerkey, $consumersecret, $accesstoken, $accesstokensecret);
           $tweets = $connection->get("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=".$twitteruser."&count=".$notweets);
           $status = json_encode($tweets);
           $fp = fopen('results.json', 'w');
            fwrite($fp, json_encode($tweets));
            fclose($fp);
            $responseJson = file_get_contents(get_home_url().'/results.json');
            if ($responseJson) {
                $response = json_decode($responseJson);
            }
            ?>
               <ul class="tweetList">
               <?php 
                    function processString($s) {
                        return preg_replace('/https?:\/\/[\w\-\.!~?&+\*\'"(),\/]+/','<a href="$0">$0</a>',$s);
                    }
               ?>
               <?php foreach ((array)$response as $tweet) { ?>
                            <?php 
                            //preg_match_all('/\b(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)[-A-Z0-9+&@#\/%=~_|$?!:,.]*[A-Z0-9+&@#\/%=~_|$]/i', $tweet->text, $result, PREG_PATTERN_ORDER);
                            //if(count($result)>0){
                                //$result = $result[0];
                                //print_r($tweet);
                            ?>
                            <li>
                            
                            <p class="t-status"><span class="icon-twitter"></span> <?php echo processString($tweet->text); //Str_replace( $result[0],' - <a href="'.$result[0].'">'.$result[0].'</a>',$tweet->text)?><br><small><?php echo $this->getAgo(strtotime($tweet->created_at)); ?></small></p>
                            </li>
                            
                <?php   
                             }   ?>
               </ul>
               <script type="text/javascript">
             //(function ($) {
//                $(document).ready(function(){
//                    $('.t-bxslider').bxSlider({
//                        slideMargin: 5,
//                        mode: 'vertical',
//                        controls: false,
//                        auto: true,
//                        pager: false,
//                        minSlides: 2,
//                        maxSlides: 2,
//                        speed: 1000,
//                        moveSlides: 1
//                    });
//                 });
//            })(jQuery);
            </script>
        <?php 
        echo $after_widget;
    }

    //Update the widget 
     
    function update( $new_instance, $old_instance ) {
        $instance = $old_instance;

        //Strip tags from title and name to remove HTML 
        $instance['title'] = strip_tags( $new_instance['title'] );
        $instance['name'] = strip_tags( $new_instance['name'] );
        $instance['num'] = strip_tags( $new_instance['num'] );
        $instance['custommerkey'] = strip_tags( $new_instance['custommerkey'] );
        $instance['custommersecret'] = strip_tags( $new_instance['custommersecret'] );
        $instance['accesstoken'] = strip_tags( $new_instance['accesstoken'] );
        $instance['accesstokensecret'] = strip_tags( $new_instance['accesstokensecret'] );
        $instance['show_info'] = $new_instance['show_info'];

        return $instance;
    }

    
    function form( $instance ) {

        //Set up some default widget settings.
        $defaults = array( 'title' => __('Latest tweets.', 'mint'), 'name' => __('quanntvn', 'mint'),'custommerkey' => __('Sv4hY9ewxyyt6ffBfMiMTg', 'mint'),'custommersecret' => __('w2AULbFWTu2kG3DnHRszG7HO4adpGCicE022MhuLYU', 'mint'),'accesstoken' => __('1361529829-lItJW8tBYhuy1zRRYpco97TdcChNcAh6wRTZxf4', 'mint'),'accesstokensecret' => __('2MRkUJLBAAp3g3PYRTcjDB4N4QaGCVf5aEuSyFaO9I', 'mint'),'num' => __(1, 'mint'));
        $instance = wp_parse_args( (array) $instance, $defaults ); ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e('Title:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo $instance['title']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'name' ); ?>"><?php _e('Tiwtter Username:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'name' ); ?>" name="<?php echo $this->get_field_name( 'name' ); ?>" value="<?php echo $instance['name']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'custommerkey' ); ?>"><?php _e('Custommer key:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'custommerkey' ); ?>" name="<?php echo $this->get_field_name( 'custommerkey' ); ?>" value="<?php echo $instance['custommerkey']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'custommersecret' ); ?>"><?php _e('Custommer Secret:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'custommersecret' ); ?>" name="<?php echo $this->get_field_name( 'custommersecret' ); ?>" value="<?php echo $instance['custommersecret']; ?>" style="width:100%;" />
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'accesstoken' ); ?>"><?php _e('Accesstoken:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'accesstoken' ); ?>" name="<?php echo $this->get_field_name( 'accesstoken' ); ?>" value="<?php echo $instance['accesstoken']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'accesstokensecret' ); ?>"><?php _e('Accesstoken Secret:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'accesstokensecret' ); ?>" name="<?php echo $this->get_field_name( 'accesstokensecret' ); ?>" value="<?php echo $instance['accesstokensecret']; ?>" style="width:100%;" />
        </p>
        <p>
            <label for="<?php echo $this->get_field_id( 'num' ); ?>"><?php _e('Number Status:', 'mint'); ?></label>
            <input id="<?php echo $this->get_field_id( 'num' ); ?>" name="<?php echo $this->get_field_name( 'num' ); ?>" value="<?php echo $instance['num']; ?>" style="width:100%;" />
        </p>
        
        //Checkbox.
        <!--<p>
            <input class="checkbox" type="checkbox" <?php checked( $instance['show_info'], true ); ?> id="<?php echo $this->get_field_id( 'show_info' ); ?>" name="<?php echo $this->get_field_name( 'show_info' ); ?>" /> 
            <label for="<?php echo $this->get_field_id( 'show_info' ); ?>"><?php _e('Display info publicly?', 'mint'); ?></label>
        </p>-->

    <?php
    }
}

?>